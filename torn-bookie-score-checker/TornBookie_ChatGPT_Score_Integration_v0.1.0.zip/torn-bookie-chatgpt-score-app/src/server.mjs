import http from "node:http";
import { readFileSync } from "node:fs";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod/v3";

const PORT = Number(process.env.PORT || 3000);
const TEMPLATE_URI = "ui://torn-bookie/score-tracker-v1.html";
const SPORT_SCORE_BASE = "https://sportscore.com";
const SPORT_SCORE_MATCHES = `${SPORT_SCORE_BASE}/api/widget/matches/`;
const SRC = "torn-bookie-chatgpt-score-app";

const DEFAULT_BETS = [
  {
    eventId: "6011053",
    sport: "tennis",
    matchup: "Lilli Tagger vs Robin Montgomery",
    pick: "Lilli Tagger",
    market: "ML",
    odds: 1.57,
    stake: 1000000,
    winCondition: "Lilli Tagger must win the match."
  },
  {
    eventId: "6011192",
    sport: "tennis",
    matchup: "Nicolai Budkov Kjaer vs Kyrian Jacquet",
    pick: "Kyrian Jacquet",
    market: "ML",
    odds: 1.50,
    stake: 1000000,
    winCondition: "Kyrian Jacquet must win the match."
  }
];

const betSchema = z.object({
  eventId: z.string().optional().default(""),
  sport: z.string().optional().default("tennis"),
  matchup: z.string().min(3),
  pick: z.string().min(1),
  market: z.string().optional().default("ML"),
  odds: z.number().positive(),
  stake: z.number().nonnegative(),
  winCondition: z.string().optional().default("")
});

const checkedBetSchema = z.object({
  eventId: z.string(),
  sport: z.string(),
  matchup: z.string(),
  pick: z.string(),
  market: z.string(),
  odds: z.number(),
  stake: z.number(),
  winCondition: z.string(),
  found: z.boolean(),
  status: z.string(),
  statusKind: z.enum(["LIVE", "UPCOMING", "FINAL", "UNKNOWN"]),
  player1: z.string(),
  player2: z.string(),
  player1Score: z.string(),
  player2Score: z.string(),
  scoreText: z.string(),
  setsText: z.string(),
  competition: z.string(),
  startTime: z.string(),
  sourceUrl: z.string(),
  result: z.enum(["WIN", "LOSS", "PENDING", "UNKNOWN"]),
  note: z.string()
});

const trackerOutputSchema = {
  checkedAt: z.string(),
  source: z.string(),
  sourceUrl: z.string(),
  bets: z.array(checkedBetSchema),
  summary: z.object({
    pending: z.number().int(),
    wins: z.number().int(),
    losses: z.number().int(),
    totalStake: z.number(),
    potentialReturn: z.number()
  })
};

function clean(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function normalize(value) {
  return clean(value)
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function splitMatchup(matchup) {
  const parts = clean(matchup).split(/\s+(?:v|vs\.?|versus)\s+/i).map(clean).filter(Boolean);
  return parts.length >= 2 ? [parts[0], parts.slice(1).join(" vs ")] : [clean(matchup), ""];
}

function surname(name) {
  const p = normalize(name).split(" ").filter(Boolean);
  return p.at(-1) || "";
}

function getPath(obj, path) {
  let cur = obj;
  for (const key of path.split(".")) {
    if (cur == null) return undefined;
    cur = cur[key];
  }
  return cur;
}

function firstValue(obj, paths) {
  for (const path of paths) {
    const value = getPath(obj, path);
    if (value !== undefined && value !== null && value !== "") return value;
  }
  return undefined;
}

function nameOf(value) {
  if (typeof value === "string" || typeof value === "number") return clean(value);
  if (!value || typeof value !== "object") return "";
  return clean(firstValue(value, ["name", "title", "shortName", "short_name", "displayName", "display_name", "player_name", "team_name"]));
}

function scoreOf(value) {
  if (value == null) return "";
  if (typeof value === "string" || typeof value === "number") return clean(value);
  if (Array.isArray(value)) return value.map(scoreOf).filter(Boolean).join(" ");
  if (typeof value === "object") {
    const preferred = firstValue(value, ["display", "current", "total", "value", "score", "games", "sets"]);
    if (preferred !== undefined) return scoreOf(preferred);
    const scalars = Object.values(value).filter(v => typeof v === "string" || typeof v === "number");
    if (scalars.length && scalars.length <= 6) return scalars.map(clean).join(" ");
  }
  return "";
}

function flattenStrings(value, out = [], depth = 0, seen = new Set()) {
  if (value == null || out.length > 300 || depth > 5) return out;
  if (typeof value === "string" || typeof value === "number") {
    const s = clean(value);
    if (s) out.push(s);
    return out;
  }
  if (typeof value !== "object" || seen.has(value)) return out;
  seen.add(value);
  if (Array.isArray(value)) {
    for (const child of value.slice(0, 100)) flattenStrings(child, out, depth + 1, seen);
  } else {
    for (const child of Object.values(value).slice(0, 100)) flattenStrings(child, out, depth + 1, seen);
  }
  return out;
}

function matchScore(match, playerA, playerB) {
  const hay = normalize(flattenStrings(match).join(" | "));
  const a = normalize(playerA);
  const b = normalize(playerB);
  const sa = surname(playerA);
  const sb = surname(playerB);
  let score = 0;
  if (a && hay.includes(a)) score += 6;
  else if (sa && hay.includes(sa)) score += 2;
  if (b && hay.includes(b)) score += 6;
  else if (sb && hay.includes(sb)) score += 2;
  if (a && b && hay.includes(a) && hay.includes(b)) score += 6;
  return score;
}

function extractSide(match, side) {
  const keys = side === 1
    ? ["home", "homeTeam", "home_team", "player1", "player_1", "firstPlayer", "first_player", "participant1", "participant_1", "competitor1", "competitor_1", "team1", "team_1"]
    : ["away", "awayTeam", "away_team", "player2", "player_2", "secondPlayer", "second_player", "participant2", "participant_2", "competitor2", "competitor_2", "team2", "team_2"];
  for (const key of keys) {
    if (match?.[key] !== undefined) {
      const n = nameOf(match[key]);
      if (n) return n;
    }
  }
  return "";
}

function extractSideScore(match, side) {
  const paths = side === 1
    ? ["homeScore", "home_score", "score.home", "scores.home", "score1", "score_1", "player1Score", "player_1_score", "firstScore", "first_score"]
    : ["awayScore", "away_score", "score.away", "scores.away", "score2", "score_2", "player2Score", "player_2_score", "secondScore", "second_score"];
  return scoreOf(firstValue(match, paths));
}

function extractSetText(match) {
  const value = firstValue(match, ["sets", "setScores", "set_scores", "periods", "scores.sets", "score.sets", "tennisScore", "tennis_score"]);
  if (value == null) return "";
  if (typeof value === "string") return clean(value);
  try {
    if (Array.isArray(value)) {
      return value.slice(0, 5).map((s, i) => {
        if (s && typeof s === "object") {
          const a = firstValue(s, ["home", "player1", "first", "score1", "score_1", "a"]);
          const b = firstValue(s, ["away", "player2", "second", "score2", "score_2", "b"]);
          if (a !== undefined || b !== undefined) return `S${i + 1} ${clean(a)}-${clean(b)}`;
        }
        return scoreOf(s);
      }).filter(Boolean).join(" · ");
    }
    return clean(JSON.stringify(value)).slice(0, 180);
  } catch {
    return "";
  }
}

function classifyStatus(raw) {
  const s = normalize(raw);
  if (!s) return "UNKNOWN";
  if (/(finished|final|ended|complete|completed|ft|after match)/.test(s)) return "FINAL";
  if (/(live|in progress|inprogress|playing|started|set \d|break)/.test(s)) return "LIVE";
  if (/(scheduled|not started|notstarted|upcoming|fixture|pending)/.test(s)) return "UPCOMING";
  return "UNKNOWN";
}

function winnerFromMatch(match, player1, player2, p1Score, p2Score) {
  const explicit = nameOf(firstValue(match, ["winner", "winnerName", "winner_name", "winningPlayer", "winning_player"]));
  if (explicit) return explicit;
  const winnerId = firstValue(match, ["winnerId", "winner_id"]);
  if (winnerId !== undefined) {
    const homeId = firstValue(match, ["home.id", "homeTeam.id", "home_team.id", "player1.id", "player_1.id"]);
    const awayId = firstValue(match, ["away.id", "awayTeam.id", "away_team.id", "player2.id", "player_2.id"]);
    if (String(winnerId) === String(homeId)) return player1;
    if (String(winnerId) === String(awayId)) return player2;
  }
  // Only infer a numeric winner when both sides are simple final numeric totals.
  if (/^\d+$/.test(p1Score) && /^\d+$/.test(p2Score)) {
    const a = Number(p1Score), b = Number(p2Score);
    if (a !== b) return a > b ? player1 : player2;
  }
  return "";
}

function sourceUrlFor(match) {
  const url = clean(firstValue(match, ["url", "matchUrl", "match_url"]));
  if (/^https?:\/\//i.test(url)) return url;
  const slug = clean(firstValue(match, ["slug", "match_slug"]));
  return slug ? `${SPORT_SCORE_BASE}/tennis/match/${slug.replace(/^\/+|\/+$/g, "")}/` : `${SPORT_SCORE_BASE}/tennis/`;
}

function normalizeMatch(match, bet) {
  const [fallback1, fallback2] = splitMatchup(bet.matchup);
  const player1 = extractSide(match, 1) || fallback1;
  const player2 = extractSide(match, 2) || fallback2;
  const player1Score = extractSideScore(match, 1);
  const player2Score = extractSideScore(match, 2);
  const genericScore = scoreOf(firstValue(match, ["scoreText", "score_text", "score", "currentScore", "current_score"]));
  const scoreText = (player1Score || player2Score) ? `${player1Score || "—"} – ${player2Score || "—"}` : genericScore;
  const status = clean(firstValue(match, ["status", "state", "matchStatus", "match_status", "statusText", "status_text", "phase"])) || "Unknown";
  const statusKind = classifyStatus(status);
  const setsText = extractSetText(match);
  const competition = nameOf(firstValue(match, ["competition", "tournament", "league"])) || clean(firstValue(match, ["competitionName", "competition_name", "tournamentName", "tournament_name", "leagueName", "league_name"]));
  const startTime = clean(firstValue(match, ["startTime", "start_time", "startTimestamp", "start_timestamp", "date", "scheduledAt", "scheduled_at"]));
  const sourceUrl = sourceUrlFor(match);
  const winner = statusKind === "FINAL" ? winnerFromMatch(match, player1, player2, player1Score, player2Score) : "";
  let result = "PENDING";
  if (statusKind === "FINAL") {
    if (!winner) result = "UNKNOWN";
    else result = normalize(winner) === normalize(bet.pick) || surname(winner) === surname(bet.pick) ? "WIN" : "LOSS";
  }
  return { player1, player2, player1Score, player2Score, scoreText, status, statusKind, setsText, competition, startTime, sourceUrl, result };
}

async function fetchSportMatches(sport) {
  if (!new Set(["tennis", "football", "basketball", "cricket"]).has(sport)) return [];
  const url = new URL(SPORT_SCORE_MATCHES);
  url.searchParams.set("sport", sport);
  url.searchParams.set("limit", "50");
  url.searchParams.set("src", SRC);
  const response = await fetch(url, {
    headers: { "User-Agent": "TornBookieChatGPTScoreApp/0.1 (+https://sportscore.com/)" },
    signal: AbortSignal.timeout(10000)
  });
  if (!response.ok) throw new Error(`SportScore returned HTTP ${response.status}`);
  const data = await response.json();
  const matches = data?.matches ?? data?.events ?? data?.data ?? [];
  return Array.isArray(matches) ? matches : [];
}

async function checkBets(inputBets) {
  const bets = inputBets?.length ? inputBets : DEFAULT_BETS;
  const bySport = new Map();
  for (const bet of bets) {
    const sport = normalize(bet.sport || "tennis").replace(/\s+/g, "-");
    if (!bySport.has(sport)) bySport.set(sport, []);
    bySport.get(sport).push(bet);
  }

  const checked = [];
  for (const [sport, sportBets] of bySport) {
    let matches = [];
    let fetchError = "";
    try {
      matches = await fetchSportMatches(sport);
    } catch (error) {
      fetchError = clean(error?.message || error);
    }

    for (const bet of sportBets) {
      const [a, b] = splitMatchup(bet.matchup);
      let best = null;
      let bestScore = -1;
      for (const match of matches) {
        const score = matchScore(match, a, b);
        if (score > bestScore) {
          bestScore = score;
          best = match;
        }
      }
      const found = Boolean(best && bestScore >= 8);
      const norm = found ? normalizeMatch(best, bet) : null;
      const supported = new Set(["tennis", "football", "basketball", "cricket"]).has(sport);
      const note = fetchError
        ? fetchError
        : !supported
          ? `SportScore does not support ${sport} in this v0.1 integration.`
          : !found
            ? "No confident match was found in SportScore's current live/recent list."
            : "Latest match data returned by SportScore.";
      checked.push({
        eventId: clean(bet.eventId),
        sport,
        matchup: clean(bet.matchup),
        pick: clean(bet.pick),
        market: clean(bet.market || "ML"),
        odds: Number(bet.odds),
        stake: Number(bet.stake),
        winCondition: clean(bet.winCondition || `${bet.pick} must win the match.`),
        found,
        status: norm?.status || (fetchError ? "Source error" : "Not found"),
        statusKind: norm?.statusKind || "UNKNOWN",
        player1: norm?.player1 || a,
        player2: norm?.player2 || b,
        player1Score: norm?.player1Score || "",
        player2Score: norm?.player2Score || "",
        scoreText: norm?.scoreText || "",
        setsText: norm?.setsText || "",
        competition: norm?.competition || "",
        startTime: norm?.startTime || "",
        sourceUrl: norm?.sourceUrl || `${SPORT_SCORE_BASE}/${sport}/`,
        result: norm?.result || "PENDING",
        note
      });
    }
  }

  const summary = {
    pending: checked.filter(b => b.result === "PENDING" || b.result === "UNKNOWN").length,
    wins: checked.filter(b => b.result === "WIN").length,
    losses: checked.filter(b => b.result === "LOSS").length,
    totalStake: checked.reduce((sum, b) => sum + b.stake, 0),
    potentialReturn: checked.filter(b => b.result === "PENDING" || b.result === "UNKNOWN").reduce((sum, b) => sum + b.stake * b.odds, 0)
  };

  return {
    checkedAt: new Date().toISOString(),
    source: "SportScore",
    sourceUrl: SPORT_SCORE_BASE,
    bets: checked,
    summary
  };
}

const widgetHtml = readFileSync(new URL("./widget.html", import.meta.url), "utf8").trim();

function createServer() {
  const server = new McpServer(
    { name: "Torn Bookie Score Tracker", version: "0.1.0" },
    { instructions: "Use render_score_tracker to display pending Torn Bookie bets. The widget's Check Scores Now button calls check_scores directly for fresh read-only sports data." }
  );

  server.registerResource("torn-bookie-score-widget", TEMPLATE_URI, {}, async () => ({
    contents: [{
      uri: TEMPLATE_URI,
      mimeType: "text/html;profile=mcp-app",
      text: widgetHtml,
      _meta: {
        ui: {
          prefersBorder: true,
          csp: {
            connectDomains: [],
            resourceDomains: ["https://sportscore.com"]
          }
        }
      }
    }]
  }));

  server.registerTool(
    "check_scores",
    {
      title: "Check pending bet scores",
      description: "Fetch the latest live/recent scores from SportScore for the supplied pending bets. Use for a manual refresh. Read-only.",
      inputSchema: { bets: z.array(betSchema).max(25).optional().default(DEFAULT_BETS) },
      outputSchema: trackerOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: true },
      _meta: {
        "openai/toolInvocation/invoking": "Checking live scores…",
        "openai/toolInvocation/invoked": "Scores checked."
      }
    },
    async ({ bets }) => {
      const result = await checkBets(bets);
      return {
        structuredContent: result,
        content: [{ type: "text", text: `Checked ${result.bets.length} pending bet(s) at ${result.checkedAt}.` }]
      };
    }
  );

  server.registerTool(
    "render_score_tracker",
    {
      title: "Show Torn Bookie score tracker",
      description: "Render the one-click Torn Bookie pending-bet score tracker. Pass the user's current pending bets when known; otherwise the two August 12 tennis bets are used as defaults.",
      inputSchema: { bets: z.array(betSchema).max(25).optional().default(DEFAULT_BETS) },
      outputSchema: trackerOutputSchema,
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
      _meta: {
        ui: { resourceUri: TEMPLATE_URI },
        "openai/outputTemplate": TEMPLATE_URI,
        "openai/toolInvocation/invoking": "Opening score tracker…",
        "openai/toolInvocation/invoked": "Score tracker ready."
      }
    },
    async ({ bets }) => {
      // Render immediately without forcing a live fetch. The button does the fetch.
      const initial = {
        checkedAt: "",
        source: "SportScore",
        sourceUrl: SPORT_SCORE_BASE,
        bets: (bets?.length ? bets : DEFAULT_BETS).map(bet => {
          const [player1, player2] = splitMatchup(bet.matchup);
          return {
            eventId: clean(bet.eventId),
            sport: normalize(bet.sport || "tennis").replace(/\s+/g, "-"),
            matchup: clean(bet.matchup),
            pick: clean(bet.pick),
            market: clean(bet.market || "ML"),
            odds: Number(bet.odds),
            stake: Number(bet.stake),
            winCondition: clean(bet.winCondition || `${bet.pick} must win the match.`),
            found: false,
            status: "Ready to check",
            statusKind: "UNKNOWN",
            player1,
            player2,
            player1Score: "",
            player2Score: "",
            scoreText: "",
            setsText: "",
            competition: "",
            startTime: "",
            sourceUrl: `${SPORT_SCORE_BASE}/tennis/`,
            result: "PENDING",
            note: "Tap Check Scores Now for a fresh lookup."
          };
        }),
        summary: {
          pending: (bets?.length ? bets : DEFAULT_BETS).length,
          wins: 0,
          losses: 0,
          totalStake: (bets?.length ? bets : DEFAULT_BETS).reduce((s,b) => s + Number(b.stake || 0), 0),
          potentialReturn: (bets?.length ? bets : DEFAULT_BETS).reduce((s,b) => s + Number(b.stake || 0) * Number(b.odds || 0), 0)
        }
      };
      return {
        structuredContent: initial,
        content: [{ type: "text", text: `Showing ${initial.bets.length} pending Torn Bookie bet(s). Use the button to refresh scores.` }]
      };
    }
  );

  return server;
}

const httpServer = http.createServer(async (req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
  if (url.pathname === "/health") {
    res.writeHead(200, { "content-type": "application/json", "cache-control": "no-store" });
    res.end(JSON.stringify({ ok: true, app: "Torn Bookie Score Tracker", version: "0.1.0" }));
    return;
  }
  if (url.pathname !== "/mcp") {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("Not found");
    return;
  }

  // A fresh stateless server/transport per request keeps this tiny read-only app
  // deployable behind ordinary Node hosting without session storage.
  const mcp = createServer();
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined,
    enableJsonResponse: false
  });
  try {
    await mcp.connect(transport);
    await transport.handleRequest(req, res);
  } catch (error) {
    console.error("MCP request failed", error);
    if (!res.headersSent) {
      res.writeHead(500, { "content-type": "application/json" });
      res.end(JSON.stringify({ error: "MCP request failed" }));
    } else if (!res.writableEnded) {
      res.end();
    }
  } finally {
    try { await transport.close(); } catch {}
    try { await mcp.close(); } catch {}
  }
});

httpServer.listen(PORT, "0.0.0.0", () => {
  console.log(`Torn Bookie Score Tracker listening on :${PORT}`);
  console.log(`MCP endpoint: http://localhost:${PORT}/mcp`);
});
