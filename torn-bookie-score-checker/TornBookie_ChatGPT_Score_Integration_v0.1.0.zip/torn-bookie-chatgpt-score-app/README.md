# Torn Bookie — ChatGPT Score Tracker v0.1

A small **read-only MCP app with an inline ChatGPT UI**. It renders the user's pending Torn Bookie bets and provides a real **Check Scores Now** button. The button calls the `check_scores` MCP tool and fetches current/recent sports data from SportScore.

## What v0.1 does

- Inline pending-bet cards in ChatGPT.
- One-click **Check Scores Now** button.
- Highlights the user's selected player.
- Displays live/upcoming/final status, score fields when SportScore exposes them, odds, stake, potential return, and the exact win condition.
- Moneyline settlement when the upstream match exposes a reliable final winner.
- No API key and no paid trial.
- Read-only: it does not place bets or write to Torn.
- Current provider coverage in this build: **tennis, football, basketball, cricket**. The current two pending tennis bets are included as defaults.

## Data source

SportScore provides a CORS-open REST API with no API key for attribution-tier projects. Its published developer docs say responses are cached roughly 60 seconds and the free tier allows about 10,000 requests per 24 hours per IP. Keep the visible `Powered by SportScore` / `Data from SportScore` link in the UI.

## Important ChatGPT availability limitation

As of August 2026, OpenAI's public documentation says private custom MCP/ChatGPT app testing through Developer Mode is available on supported workspace plans (Business, Enterprise, Edu) on **ChatGPT web**. OpenAI's Developer Mode help page says custom MCP apps are **not available on mobile**.

That means this is a real ChatGPT MCP integration, but it cannot be attached to an ordinary Android chat today unless/ until your ChatGPT account/workspace has the required custom-app access on web.

## Run locally

Requirements: Node.js 20+.

```bash
npm install
npm start
```

Health check:

```bash
curl http://localhost:3000/health
```

MCP endpoint:

```text
http://localhost:3000/mcp
```

For MCP Inspector:

```bash
npx @modelcontextprotocol/inspector@latest
```

Choose **Streamable HTTP** and connect to `http://localhost:3000/mcp`.

## Deploy

The project includes a `Dockerfile` and a small `render.yaml`. Any stable HTTPS Node/container host is fine. The deployed endpoint must be reachable as:

```text
https://YOUR-HOST/mcp
```

OpenAI's MCP docs require a stable Streamable HTTP endpoint, typically `/mcp`, for remote connections.

## Connect to ChatGPT (when Developer Mode is available)

OpenAI's current flow is:

1. Use ChatGPT **on the web**.
2. Enable Developer Mode if your workspace/account allows it.
3. Open ChatGPT Plugins/custom app connection settings.
4. Add a new MCP connection.
5. Enter your public HTTPS endpoint, including `/mcp`.
6. Review the two discovered read-only tools:
   - `render_score_tracker`
   - `check_scores`
7. Start a new chat with the app enabled.
8. Ask: `Show my Torn Bookie score tracker.`
9. Press **Check Scores Now** inside the rendered tracker.

## Updating pending bets

The `render_score_tracker` tool accepts an array of bets. ChatGPT can pass the pending bets from the conversation into the widget. Each bet uses:

```json
{
  "eventId": "6011053",
  "sport": "tennis",
  "matchup": "Lilli Tagger vs Robin Montgomery",
  "pick": "Lilli Tagger",
  "market": "ML",
  "odds": 1.57,
  "stake": 1000000,
  "winCondition": "Lilli Tagger must win the match."
}
```

## Notes

- SportScore's list endpoint is intentionally simple. If a niche match is not present in the current live/recent list, the card says no confident match was found rather than guessing.
- v0.1 is intentionally conservative about settlement. It marks WIN/LOSS only when a final winner can be determined reliably from upstream data.
- This project does not send anything to Torn.
